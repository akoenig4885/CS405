// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_order
  //  varaible, and its position in the declaration. It must always be directly before the variable used for input.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  //Define variables for the maximum input size, number of input characters, and loop control variable
  const int INPUT_SIZE = 20;
  int i = 0;
  bool inputValid = false;
  // Loop unitl valid input is received from the user
  while (!inputValid) {
	  std::cout << "Enter a value: ";
	  // Read user input, one character at a time
	  while (std::cin.get(user_input[i]))
	  {
		  // If the input character, is the newline character, the end of user input has been reached
		  if (user_input[i] == '\n') {
			  // Set the current index of user_input to a null character, which is used to truncate c strings
			  user_input[i] = '\0';
			  // If the input reached the newline character without hitting the limit, the input was valid
			  inputValid = true;
			  // Exit the loop
			  break;
		  }
		  // Increment the number of input characters
		  i++;
		  // If the number of input characters reaches the input size, buffer overflow will occur when attempting to read another character
		  if (i >= INPUT_SIZE) {
			  // Set the end of the c string to the null character
			  user_input[i - 1] = '\0';
			  // Inform the user of the buffer overflow
			  std::cout << "Buffer overflow detected. Please enter no more than 20 characters." << std::endl;
			  // Clear the input stream and set the number of input characters back to zero
			  std:: cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			  i = 0;
			  break;
		  }

	  }
  }
  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
